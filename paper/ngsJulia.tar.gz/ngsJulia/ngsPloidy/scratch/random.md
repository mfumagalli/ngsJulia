
RANDOM THOUGHTS

- for low-depth it is very hard to infer ploidies > 2; perhaps it would be more useful to provide confidence intervals, showing the uncertainty of assigning a ploidy

- for low-depth with uncertain depth, perhaps one can compute summary statistics by integrating across all possibe ploidies weighting by their probability

- when many sites are available, the posterior probs are totally dominated by the likelihood and the priors is not relevant

- perhaps for sliding windows scan of ploidy along a chromosome, it could be useful to use a prior based on the whole chromosome (for single-sample analyses)





